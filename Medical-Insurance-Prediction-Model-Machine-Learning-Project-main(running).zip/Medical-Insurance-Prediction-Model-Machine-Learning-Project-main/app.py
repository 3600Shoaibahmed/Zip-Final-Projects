import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import streamlit as st

# Load and preprocess dataset
medical_df = pd.read_csv('insurance.csv')
medical_df.replace({'sex': {'male': 0, 'female': 1},
                    'smoker': {'yes': 0, 'no': 1},
                    'region': {'southeast': 0, 'southwest': 1, 'northwest': 2, 'northeast': 3}}, inplace=True)

# Features and target
X = medical_df.drop('charges', axis=1)
y = medical_df['charges']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=2)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Streamlit UI
st.title("Medical Insurance Prediction Model")

st.write(f"Model R² Score: {r2_score(y_test, y_pred):.2f}")

# Input fields
age = st.number_input("Age", min_value=0, max_value=120, value=25)
sex = st.selectbox("Sex", ["male", "female"])
bmi = st.number_input("BMI", min_value=0.0, max_value=100.0, value=28.5)
children = st.number_input("Number of Children", min_value=0, max_value=10, value=0)
smoker = st.selectbox("Smoker", ["yes", "no"])
region = st.selectbox("Region", ["southeast", "southwest", "northwest", "northeast"])

# Map categorical variables to numeric
sex_val = 0 if sex == "male" else 1
smoker_val = 0 if smoker == "yes" else 1
region_val = {"southeast": 0, "southwest": 1, "northwest": 2, "northeast": 3}[region]

# Create input array
input_features = np.array([age, sex_val, bmi, children, smoker_val, region_val]).reshape(1, -1)

# Prediction
if st.button("Predict Insurance Charge"):
    prediction = model.predict(input_features)
    st.success(f"Estimated Medical Insurance Charge: ${prediction[0]:.2f}")
