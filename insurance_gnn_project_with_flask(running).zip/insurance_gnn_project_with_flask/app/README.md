# Insurance Fraud Detection (GNN + Flask)

## Setup
```bash
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```

## Generate synthetic data
```bash
python data/generate_synthetic.py --n_claims 5000 --out_dir data/
```

## Train model
```bash
python src/train.py --graph_path data/graph_hetero.pt --save_dir models --epochs 10
```

## Evaluate model
```bash
python src/evaluate.py --data_dir data --model_path models/graphsage_best.pt
```

## Run Flask UI
```bash
cd app
python app.py
```
Then open http://127.0.0.1:5000
