import argparse, os, pandas as pd, numpy as np

def generate_data(n_claims=1000, out_dir="data"):
    os.makedirs(out_dir, exist_ok=True)
    np.random.seed(42)
    claims = []
    persons = []
    providers = []
    for i in range(n_claims):
        claim_id = f"C{i:06d}"
        person_id = f"P{i%200:05d}"
        provider_id = f"R{i%50:04d}"
        amount = np.random.randint(100, 10000)
        num_items = np.random.randint(1, 5)
        fraud = np.random.choice([0,1], p=[0.9,0.1])
        claims.append([claim_id, person_id, provider_id, amount, num_items, fraud])
        persons.append([person_id, np.random.randint(18,70)])
        providers.append([provider_id, np.random.choice(['clinic','hospital','lab'])])
    claims_df = pd.DataFrame(claims, columns=["claim_id","person_id","provider_id","claim_amount","num_items","fraud_label"])
    persons_df = pd.DataFrame(persons, columns=["person_id","age"]).drop_duplicates()
    providers_df = pd.DataFrame(providers, columns=["provider_id","type"]).drop_duplicates()
    claims_df.to_csv(os.path.join(out_dir, "claims.csv"), index=False)
    persons_df.to_csv(os.path.join(out_dir, "persons.csv"), index=False)
    providers_df.to_csv(os.path.join(out_dir, "providers.csv"), index=False)
    print("Generated dataset with", len(claims_df), "claims.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_claims", type=int, default=1000)
    parser.add_argument("--out_dir", type=str, default="data")
    args = parser.parse_args()
    generate_data(args.n_claims, args.out_dir)
