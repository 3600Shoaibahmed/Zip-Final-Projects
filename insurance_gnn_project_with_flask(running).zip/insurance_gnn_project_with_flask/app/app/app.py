from flask import Flask, render_template, request
import torch
import pandas as pd
import numpy as np
import os
import traceback

# Import your trained model class
try:
    from src.models import GraphSAGE
except Exception:
    GraphSAGE = None

app = Flask(__name__)

# Load claims dataset
CLAIMS_PATH = os.path.join(os.path.dirname(BASE_PATH := os.path.dirname(__file__)), "data", "claims.csv")
if not os.path.exists(CLAIMS_PATH):
    # handle path when running from repo root
    CLAIMS_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "claims.csv")

try:
    claims_df = pd.read_csv(CLAIMS_PATH)
except Exception as e:
    claims_df = pd.DataFrame(columns=['claim_id','claim_amount','num_items','fraud_label'])
    print("Could not load claims.csv:", e)

# Load trained model (GraphSAGE placeholder)
MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "models", "graphsage_best.pt")
device = torch.device("cpu")

# For demo, create a dummy model and random predictions
# Replace with your trained GNN + embeddings pipeline for production results
class DummyModel:
    def predict_proba(self, X):
        return np.random.rand(len(X), 2)

def load_model():
    if os.path.exists(MODEL_PATH) and GraphSAGE is not None:
        try:
            # Try to infer in_channels from claims.csv columns if present
            in_ch = 2
            model = GraphSAGE(in_channels=in_ch, hidden_channels=64, out_channels=2)
            model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
            model.eval()
            return model
        except Exception as e:
            print("Failed to load real model, falling back to DummyModel:", e)
            return DummyModel()
    else:
        return DummyModel()

model = load_model()

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error = None
    try:
        if request.method == "POST":
            claim_id = request.form["claim_id"].strip()
            row = claims_df[claims_df["claim_id"] == claim_id]
            if row.empty:
                error = f"Claim ID '{claim_id}' not found. Try listing claim IDs with `head -n 5 data/claims.csv`."
            else:
                # Simple input vector (claim_amount, num_items) for demo
                x_vals = row[["claim_amount", "num_items"]].fillna(0).values.astype(float)
                x = torch.tensor(x_vals, dtype=torch.float)
                with torch.no_grad():
                    if isinstance(model, DummyModel):
                        probs = model.predict_proba(x)
                    else:
                        out = model(x, torch.empty((2,0), dtype=torch.long))
                        probs = torch.softmax(out, dim=1).numpy()
                fraud_prob = float(probs[0][1])
                label = "Fraudulent" if fraud_prob > 0.5 else "Genuine"
                explanation = ("Model indicates unusually high claim amount and repeated provider links."
                               if fraud_prob > 0.5 else "No abnormal pattern detected in basic features.")

                result = {"claim_id": claim_id, "fraud_prob": fraud_prob, "label": label, "explanation": explanation}
    except Exception as e:
        error = "Server error: " + str(e) + "\n" + traceback.format_exc()
    return render_template("index.html", result=result, error=error)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
