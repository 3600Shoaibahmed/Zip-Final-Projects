import argparse, pandas as pd, torch,os,sys
from sklearn.metrics import classification_report, roc_auc_score
sys.path.append(os.path.abspath(".."))
from src.models import GraphSAGE

def evaluate(data_dir, model_path):
    claims = pd.read_csv(f"{data_dir}/claims.csv")
    X = torch.tensor(claims[["claim_amount","num_items"]].values, dtype=torch.float)
    y = claims["fraud_label"].values
    model = GraphSAGE(in_channels=2, hidden_channels=16, out_channels=2)
    model.load_state_dict(torch.load(model_path, map_location="cpu"))
    model.eval()
    with torch.no_grad():
        out = model(X)
        preds = out.argmax(dim=1).numpy()
        probs = torch.softmax(out,dim=1)[:,1].numpy()
    print(classification_report(y, preds))
    print("ROC-AUC:", roc_auc_score(y, probs))

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--data_dir", default="data")
    parser.add_argument("--model_path", default="models/graphsage_best.pt")
    args=parser.parse_args()
    evaluate(args.data_dir, args.model_path)
