import argparse, torch, pandas as pd, os
import sys
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

sys.path.append(os.path.abspath(".."))
from torch import nn, optim
from src.models import GraphSAGE

def train(graph_path, save_dir, epochs=5):
    os.makedirs(save_dir, exist_ok=True)
    # Load synthetic dataset
    claims = pd.read_csv("data\claims.csv")
    X = torch.tensor(claims[["claim_amount","num_items"]].values, dtype=torch.float)
    y = torch.tensor(claims["fraud_label"].values, dtype=torch.long)
    model = GraphSAGE(in_channels=2, hidden_channels=16, out_channels=2)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    for epoch in range(epochs):
        optimizer.zero_grad()
        out = model(X)
        loss = criterion(out, y)
        loss.backward()
        optimizer.step()
        print(f"Epoch {epoch+1}/{epochs} - Loss: {loss.item():.4f}")
    torch.save(model.state_dict(), os.path.join(save_dir,"graphsage_best.pt"))
    print("Model saved to", save_dir)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--graph_path", default="data/graph_hetero.pt")
    parser.add_argument("--save_dir", default="models")
    parser.add_argument("--epochs", type=int, default=5)
    args=parser.parse_args()
    train(args.graph_path, args.save_dir, args.epochs)
