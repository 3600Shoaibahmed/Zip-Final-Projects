import torch
from torch import nn
import sys, os
sys.path.append(os.path.abspath(".."))

class GraphSAGE(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super().__init__()
        self.lin1 = nn.Linear(in_channels, hidden_channels)
        self.lin2 = nn.Linear(hidden_channels, out_channels)

    def forward(self, x, edge_index=None):
        # Placeholder forward (no message passing)
        h = torch.relu(self.lin1(x))
        out = self.lin2(h)
        return out

class GAT(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super().__init__()
        self.lin1 = nn.Linear(in_channels, hidden_channels)
        self.lin2 = nn.Linear(hidden_channels, out_channels)
    def forward(self, x, edge_index=None):
        h = torch.relu(self.lin1(x))
        return self.lin2(h)
