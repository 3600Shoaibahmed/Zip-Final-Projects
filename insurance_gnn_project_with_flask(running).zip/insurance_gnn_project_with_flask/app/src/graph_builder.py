import argparse, os, pandas as pd, torch

def build_graph(data_dir, out_path):
    # Placeholder: In real project, convert CSVs to PyG HeteroData
    claims = pd.read_csv(os.path.join(data_dir,"claims.csv"))
    graph_meta = {"n_claims": len(claims)}
    torch.save(graph_meta, out_path)
    print("Saved graph metadata to", out_path)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--data_dir", default="data")
    parser.add_argument("--out_path", default="data/graph_hetero.pt")
    args=parser.parse_args()
    build_graph(args.data_dir, args.out_path)
